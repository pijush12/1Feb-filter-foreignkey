from multiprocessing import Value
from django.shortcuts import render
from .serializers import SingerSerializer, SongSerializer
from rest_framework import viewsets
from .models import Singer,Song
from rest_framework import generics
from rest_framework.exceptions import ValidationError
import json
from django.core import serializers

# Create your views here.

class SingerViewSet(viewsets.ModelViewSet):
    queryset=Singer.objects.all()
    serializer_class= SingerSerializer

class SongViewSet(viewsets.ModelViewSet):
    queryset=Song.objects.all()
    serializer_class=SongSerializer    



class GetItemFromSinger(generics.ListAPIView):
    serializer_class = SingerSerializer
    serializer_class=SongSerializer
    
    def get_queryset(self):
        #name=self.kwargs['name']
        data=self.request.data
        name=data.get("name")
        #id=data.get("id")
        #roll=data.get("roll")
        #city=data.get("city")
        #print(city)
        #res=Singer.objects.filter()
        #queryset=Singer.objects.filter(name__icontains=name).values_list('id', flat=True)
        #print(queryset)

        queryset = Singer.objects.filter(name__iexact=name)
        a=queryset[0].id
        print(a)
        #queryset = Student.objects.filter(name__iexact=name).filter(id=id)   #use for and operation
        #queryset = Student.objects.filter(name__iexact=name) | Student.objects.filter(id=id)   #use for or operation
        #queryset = Student.objects.filter(roll__gte=roll)   #use for greater than equal
        #queryset = Student.objects.order_by('roll')  #use for orderby roll no
        #queryset = Student.objects.order_by('name')   #use for greater than equal

        
        #a=serializers.serialize("json",Singer.objects.filter(name__icontains=name))
        #print(a[0][0])
        #ids    = res.values_list('pk', flat=True)
        
        #a=int(list(ids[0]))
        #print(a)

        res=Song.objects.filter(singer=a)
        if res:
            

            
            return res
        else:
             #raise ValidationError({"error": ["You don't have enough permission."]})
             raise ValidationError("Not data matching")
