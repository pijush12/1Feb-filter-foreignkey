from django.forms import fields
from .models import Singer, Song
from rest_framework import serializers 

class SongSerializer(serializers.ModelSerializer):
    class Meta:
        model=Song
        fields=['id','title','singer','duration']



class SingerSerializer(serializers.ModelSerializer):
    singer_songs=SongSerializer(many=True)
    class Meta:
        model=Singer
        fields=['id','name','gender','singer_songs']


